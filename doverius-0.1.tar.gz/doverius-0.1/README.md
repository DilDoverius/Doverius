# justanything

Простой пакет, содержащий функцию `test()` — она печатает "hello world".
